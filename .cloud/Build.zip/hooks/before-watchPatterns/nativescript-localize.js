module.exports = require("nativescript-localize/hooks/before-watchPatterns.js");
