module.exports = require("nativescript-localize/hooks/before-checkForChanges.js");
